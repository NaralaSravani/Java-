package com.cg.project.daoservices;

import com.cg.project.beans.Employee;

public interface DAOServices {
	void insert(Employee employee);
	void update(Employee employee);
	void delete(Employee employee);
	Employee getEmployee(int employeeId);
}
