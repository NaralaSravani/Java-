package com.cg.project.daoservices;

import java.awt.image.RescaleOp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.project.beans.Employee;
import com.cg.project.provider.ConnectionProvider;

public class DAOServicesImpl implements DAOServices {

	Connection con ;
	
	public DAOServicesImpl() {
		con= ConnectionProvider.getDBConnection();
	} 
	@Override
	public void insert(Employee employee) {
		
		try {
			PreparedStatement pstmt = con.prepareStatement("insert into Employee(employeeId, basicSalary, totalSalary,firstName, lastName) values(?,?,?,?,?)");
			pstmt.setInt(1, employee.getEmployeeId());
			pstmt.setInt(2, employee.getBasicSalary());
			pstmt.setInt(3, employee.getTotalSalary());
			pstmt.setString(4, employee.getFirstName());
			pstmt.setString(5, employee.getLastName());
			
			int n=pstmt.executeUpdate();
			System.out.println(n+ " Row inserted");
			
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}

	@Override
	public void update(Employee employee) {
		
		
	}

	@Override
	public void delete(Employee employee) {
		
		
	}

	@Override
	public Employee getEmployee(int employeeId) {
		
		try {
			PreparedStatement pstmt = con.prepareStatement("select * from Employee where employeeId="+employeeId);
			ResultSet rs =  pstmt.executeQuery();
			if(rs.next()) {
				String firstName=rs.getString("firstName");
				String lastName=rs.getString("lastName");
				int basicSalary =rs.getInt("basicSalary");
				int totalSalary=rs.getInt("totalSalary");
				return new Employee(employeeId, basicSalary, firstName, lastName);		
			}			
		} catch (SQLException e) {		
			e.printStackTrace();
		}
		
		return null;
	}

}
