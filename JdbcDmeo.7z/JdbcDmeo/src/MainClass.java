import com.cg.project.beans.Employee;
import com.cg.project.daoservices.DAOServices;
import com.cg.project.daoservices.DAOServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		DAOServices daoServices = new DAOServicesImpl();
		daoServices.insert(new Employee(100, 12000, "Satish", "Mahajan"));
	}

}
